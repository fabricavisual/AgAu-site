<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<span class="cart__quantity-badge stm_hb_mbc"><?php echo WC()->cart->get_cart_contents_count(); ?></span>